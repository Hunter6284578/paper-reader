import { Routes, Route } from 'react-router-dom';
import { useBackButton } from './hooks/useBackButton';
import PaperList from './pages/PaperList';
import PaperReader from './pages/PaperReader';
import VocabBook from './pages/VocabBook';
import ReviewSession from './pages/ReviewSession';

function App() {
  // Android 返回键处理
  useBackButton();

  return (
    <Routes>
      <Route path="/" element={<PaperList />} />
      <Route path="/paper/:id" element={<PaperReader />} />
      <Route path="/vocab" element={<VocabBook />} />
      <Route path="/review" element={<ReviewSession />} />
    </Routes>
  );
}

export default App;
