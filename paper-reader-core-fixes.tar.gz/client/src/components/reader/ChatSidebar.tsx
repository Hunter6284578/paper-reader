import { useEffect, useRef } from 'react';
import { useChatStore } from '../../stores/chatStore';

interface ChatSidebarProps {
  paperId: string;
  onClose: () => void;
}

export default function ChatSidebar({ paperId, onClose }: ChatSidebarProps) {
  const { messages, streamContent, isStreaming, fetchHistory, sendMessage } = useChatStore();
  const inputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchHistory(paperId);
  }, [paperId]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamContent]);

  const handleSend = async () => {
    const text = inputRef.current?.value.trim();
    if (!text || isStreaming) return;
    inputRef.current!.value = '';
    try {
      await sendMessage(paperId, text);
    } catch (e: any) {
      alert(e.message || 'AI 问答失败');
    }
  };

  return (
    <div className="w-full lg:w-96 border-l border-gray-200 bg-white flex flex-col shrink-0">
      <div className="p-3 border-b border-gray-100 flex items-center justify-between">
        <h3 className="font-medium text-sm text-gray-900">AI 论文伴读</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-sm">✕</button>
      </div>

      <div className="flex-1 overflow-auto p-3 space-y-3 scroll-container">
        {messages.length === 0 && !isStreaming && (
          <div className="text-center text-gray-400 text-sm py-8">
            <p>向 AI 提问关于这篇论文的问题</p>
            <p className="mt-1 text-xs">如：这篇论文的主要贡献是什么？</p>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`text-sm ${
              msg.role === 'user'
                ? 'bg-primary-50 text-primary-900 rounded-lg p-3 ml-4'
                : 'bg-gray-50 text-gray-800 rounded-lg p-3 mr-4'
            }`}
          >
            <p className="whitespace-pre-wrap">{msg.content}</p>
            {msg.references.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1">
                {msg.references.map((ref) => (
                  <span key={ref.index} className="text-xs bg-gray-200 text-gray-600 px-1.5 py-0.5 rounded">
                    [{ref.index}]
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}

        {isStreaming && (
          <div className="bg-gray-50 rounded-lg p-3 mr-4">
            <p className="text-sm text-gray-800 whitespace-pre-wrap">
              {streamContent || '思考中...'}
            </p>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      <div className="p-3 border-t border-gray-100">
        <div className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            placeholder="输入问题..."
            className="input-field text-sm flex-1"
            disabled={isStreaming}
          />
          <button
            onClick={handleSend}
            className="btn-primary text-sm px-3"
            disabled={isStreaming}
          >
            发送
          </button>
        </div>
      </div>
    </div>
  );
}
