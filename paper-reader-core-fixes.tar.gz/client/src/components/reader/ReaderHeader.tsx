import { useNavigate } from 'react-router-dom';
import { useReaderStore } from '../../stores/readerStore';

interface ReaderHeaderProps {
  title: string;
  isDesktop: boolean;
  showChat: boolean;
  onToggleChat: () => void;
  processingStatus: string;
}

export default function ReaderHeader({
  title,
  isDesktop,
  showChat,
  onToggleChat,
  processingStatus,
}: ReaderHeaderProps) {
  const navigate = useNavigate();
  const settings = useReaderStore((s) => s.settings);
  const toggleSettings = useReaderStore((s) => s.toggleSettings);
  const toggleToc = useReaderStore((s) => s.toggleToc);
  const isDark = settings.theme === 'dark';

  return (
    <header
      className={`shrink-0 px-4 py-2.5 flex items-center gap-3 border-b transition-colors ${
        isDark
          ? 'bg-gray-800 border-gray-700'
          : 'bg-white/90 backdrop-blur-sm border-gray-200'
      }`}
    >
      <button
        onClick={() => navigate('/')}
        className={`shrink-0 ${isDark ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'}`}
      >
        ←
      </button>

      <button
        onClick={toggleToc}
        className={`shrink-0 text-lg ${isDark ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900'}`}
        title="目录"
      >
        ☰
      </button>

      <h2 className={`font-medium truncate flex-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
        {title}
      </h2>

      {processingStatus === 'processing' && (
        <span className="text-xs text-yellow-600 bg-yellow-50 px-2 py-0.5 rounded shrink-0">
          处理中...
        </span>
      )}

      <button
        onClick={toggleSettings}
        className={`shrink-0 px-2.5 py-1 rounded-lg text-sm ${
          isDark ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        ⚙
      </button>

      <button
        onClick={onToggleChat}
        className={`shrink-0 px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
          showChat
            ? 'bg-primary-600 text-white'
            : isDark
            ? 'bg-gray-700 text-gray-200 hover:bg-gray-600'
            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
        }`}
      >
        {isDesktop ? 'AI 问答' : 'AI'}
      </button>
    </header>
  );
}
