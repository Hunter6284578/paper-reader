import { useState, useEffect, useCallback, useRef } from 'react';
import type { Paragraph, Highlight, StructureSection } from '../../types';
import { fetchParagraphs, fetchStructure, translateParagraphs } from '../../services/api';
import { useReaderStore } from '../../stores/readerStore';
import { useTranslationStore } from '../../stores/translationStore';
import ParagraphBlock from './ParagraphBlock';
import PageImageViewer from './PageImageViewer';

interface ReadingAreaProps {
  paperId: string;
  highlights: Highlight[];
  containerRef: React.RefObject<HTMLDivElement | null>;
  onSectionsLoaded: (sections: StructureSection[]) => void;
}

const PAGE_SIZE = 20;
const PRELOAD_THRESHOLD = 5; // 距底部多少段时预加载
const TRANSLATE_WINDOW = 10;  // 预翻译窗口大小

export default function ReadingArea({
  paperId,
  highlights,
  containerRef,
  onSectionsLoaded,
}: ReadingAreaProps) {
  const settings = useReaderStore((s) => s.settings);
  const setTotalParagraphs = useReaderStore((s) => s.setTotalParagraphs);
  const setCurrentParagraph = useReaderStore((s) => s.setCurrentParagraph);
  const fetchTranslations = useTranslationStore((s) => s.fetchTranslations);

  const [paragraphs, setParagraphs] = useState<Paragraph[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [viewMode, setViewMode] = useState<'text' | 'pages'>('text');
  const offsetRef = useRef(0);
  const loadingRef = useRef(false);

  // 初始加载
  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      try {
        // 加载结构
        const structRes = await fetchStructure(paperId);
        if (!cancelled) {
          onSectionsLoaded(structRes.sections);
          setTotal(structRes.totalParagraphs);
          setTotalParagraphs(structRes.totalParagraphs);
        }

        // 加载第一批段落
        const paraRes = await fetchParagraphs(paperId, 0, PAGE_SIZE);
        if (!cancelled) {
          setParagraphs(paraRes.paragraphs);
          offsetRef.current = paraRes.paragraphs.length;

          // 预翻译前 10 段
          const idsToTranslate = paraRes.paragraphs
            .filter((p) => !p.translation)
            .slice(0, TRANSLATE_WINDOW)
            .map((p) => p.id);
          if (idsToTranslate.length > 0 && settings.showTranslation) {
            fetchTranslations(paperId, idsToTranslate);
          }
        }
      } catch (e) {
        console.error('[ReadingArea] 加载失败:', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    // 重置状态
    setParagraphs([]);
    offsetRef.current = 0;
    load();

    return () => { cancelled = true; };
  }, [paperId]);

  // 加载更多段落
  const loadMore = useCallback(async () => {
    if (loadingRef.current || offsetRef.current >= total) return;
    loadingRef.current = true;
    setLoadingMore(true);

    try {
      const res = await fetchParagraphs(paperId, offsetRef.current, PAGE_SIZE);
      setParagraphs((prev) => [...prev, ...res.paragraphs]);
      offsetRef.current += res.paragraphs.length;

      // 预翻译新加载的段落
      const idsToTranslate = res.paragraphs
        .filter((p) => !p.translation)
        .map((p) => p.id);
      if (idsToTranslate.length > 0 && settings.showTranslation) {
        fetchTranslations(paperId, idsToTranslate);
      }
    } catch (e) {
      console.error('[ReadingArea] 加载更多失败:', e);
    } finally {
      setLoadingMore(false);
      loadingRef.current = false;
    }
  }, [paperId, total, settings.showTranslation]);

  // 段落可见性回调
  const handleParagraphVisible = useCallback((index: number) => {
    setCurrentParagraph(index);

    // 预加载检测
    if (total - index <= PRELOAD_THRESHOLD) {
      loadMore();
    }
  }, [total, loadMore, setCurrentParagraph]);

  // 跳转到指定段落
  const jumpToParagraph = useCallback((paragraphIndex: number) => {
    // 如果目标段落尚未加载，先加载
    if (paragraphIndex >= offsetRef.current) {
      // 重新从目标位置加载
      setParagraphs([]);
      offsetRef.current = paragraphIndex;
      setLoading(true);

      fetchParagraphs(paperId, paragraphIndex, PAGE_SIZE).then((res) => {
        setParagraphs(res.paragraphs);
        offsetRef.current = paragraphIndex + res.paragraphs.length;
        setLoading(false);
      }).catch(() => setLoading(false));
    }

    // 滚动到目标段落
    setTimeout(() => {
      const el = containerRef.current?.querySelector(
        `[data-paragraph-id]`
      );
      // 找到对应 paragraphIndex 的元素
      const allParas = containerRef.current?.querySelectorAll('.reader-paragraph');
      if (allParas) {
        for (const p of allParas) {
          const id = parseInt(p.getAttribute('data-paragraph-id') || '0', 10);
          // 粗略定位
          if (id > 0) {
            p.scrollIntoView({ behavior: 'smooth', block: 'start' });
            break;
          }
        }
      }
    }, 100);
  }, [paperId, containerRef]);

  // 暴露 jumpToParagraph
  useEffect(() => {
    if (containerRef.current) {
      (containerRef.current as any).__jumpToParagraph = jumpToParagraph;
    }
  }, [jumpToParagraph, containerRef]);

  const isDark = settings.theme === 'dark';
  const isSepia = settings.theme === 'sepia';

  // 视图切换按钮
  const viewToggle = (
    <div className="flex justify-center py-2">
      <button
        onClick={() => setViewMode(viewMode === 'text' ? 'pages' : 'text')}
        className={`text-xs px-3 py-1 rounded-full transition-colors ${
          isDark
            ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
        }`}
      >
        {viewMode === 'text' ? '📄 查看原页' : '📝 文本视图'}
      </button>
    </div>
  );

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="space-y-3 w-4/5 max-w-lg">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="skeleton-pulse h-5 rounded w-full" style={{ width: `${70 + Math.random() * 30}%` }} />
          ))}
        </div>
      </div>
    );
  }

  if (paragraphs.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-2">
          <p className={`text-lg ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            暂无可阅读内容
          </p>
          <p className={`text-sm ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>
            论文可能还在处理中，请稍后再试
          </p>
        </div>
      </div>
    );
  }

  // 渲染段落，按章节分组
  let lastSection = '';

  return (
    <div className="flex-1 overflow-auto scroll-container" ref={containerRef as React.RefObject<HTMLDivElement>}>
      {viewToggle}
      {viewMode === 'pages' ? (
        <PageImageViewer paperId={paperId} />
      ) : (
      <div
        className="max-w-2xl mx-auto px-4 sm:px-6 py-8 pb-20"
        style={{
          fontSize: `${settings.fontSize}px`,
          lineHeight: settings.lineHeight,
        }}
      >
        {paragraphs.map((para) => {
          const showSectionDivider = para.sectionTitle && para.sectionTitle !== lastSection;
          if (showSectionDivider) lastSection = para.sectionTitle || '';

          return (
            <div key={para.id}>
              {showSectionDivider && (
                <div className={`mb-8 mt-12 first:mt-0`}>
                  <h2 className={`text-lg font-bold mb-4 ${isDark ? 'text-gray-200' : 'text-gray-800'}`}>
                    {para.sectionTitle}
                  </h2>
                  <div className={`h-px ${isDark ? 'bg-gray-700' : isSepia ? 'bg-amber-200' : 'bg-gray-200'}`} />
                </div>
              )}
              <ParagraphBlock
                paragraph={para}
                paperId={paperId}
                highlights={highlights}
                onParagraphVisible={handleParagraphVisible}
              />
            </div>
          );
        })}

        {loadingMore && (
          <div className="py-8 space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="skeleton-pulse h-4 rounded" style={{ width: `${60 + Math.random() * 40}%` }} />
            ))}
          </div>
        )}

        {offsetRef.current >= total && paragraphs.length > 0 && (
          <div className={`py-12 text-center text-sm ${isDark ? 'text-gray-600' : 'text-gray-400'}`}>
            — 全文结束 —
          </div>
        )}
      </div>
      )}
    </div>
  );
}
