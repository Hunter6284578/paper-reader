import { useState, useEffect, useCallback, useRef } from 'react';

interface TextSelection {
  text: string;
  paragraphId: number | null;
  startOffset: number;
  endOffset: number;
  rect: DOMRect | null;
}

export function useTextSelection(containerRef: React.RefObject<HTMLElement | null>) {
  const [selection, setSelection] = useState<TextSelection | null>(null);
  const selectionRef = useRef<TextSelection | null>(null);

  const clearSelection = useCallback(() => {
    setSelection(null);
    selectionRef.current = null;
  }, []);

  const handleSelection = useCallback(() => {
    const sel = window.getSelection();
    const text = sel?.toString().trim();

    if (!text || text.length === 0) {
      clearSelection();
      return;
    }

    const range = sel?.getRangeAt(0);
    if (!range) {
      clearSelection();
      return;
    }

    // 检查选区是否在容器内
    const container = containerRef.current;
    if (!container || !container.contains(range.commonAncestorContainer)) {
      return;
    }

    // 找到最近的段落元素
    let node: Node | null = range.commonAncestorContainer;
    let paragraphEl: HTMLElement | null = null;

    while (node && node !== container) {
      if (node instanceof HTMLElement && node.dataset.paragraphId) {
        paragraphEl = node;
        break;
      }
      node = node.parentNode;
    }

    const paragraphId = paragraphEl
      ? parseInt(paragraphEl.dataset.paragraphId || '0', 10)
      : null;

    // 计算字符偏移
    let startOffset = 0;
    let endOffset = text.length;

    if (paragraphEl) {
      const textContent = paragraphEl.textContent || '';
      const fullSelection = text;

      // 简单方式：在段落文本中查找选中文本
      const idx = textContent.indexOf(fullSelection);
      if (idx >= 0) {
        startOffset = idx;
        endOffset = idx + fullSelection.length;
      }
    }

    const result: TextSelection = {
      text,
      paragraphId,
      startOffset,
      endOffset,
      rect: range.getBoundingClientRect(),
    };

    setSelection(result);
    selectionRef.current = result;
  }, [containerRef, clearSelection]);

  useEffect(() => {
    const handleMouseUp = () => {
      // 延迟执行，让浏览器完成选区更新
      setTimeout(handleSelection, 10);
    };

    const handleTouchEnd = () => {
      setTimeout(handleSelection, 100);
    };

    document.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('touchend', handleTouchEnd);
    document.addEventListener('keydown', (e) => {
      // Esc 清除选区
      if (e.key === 'Escape') clearSelection();
    });

    return () => {
      document.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, [handleSelection, clearSelection]);

  return { selection, clearSelection };
}
