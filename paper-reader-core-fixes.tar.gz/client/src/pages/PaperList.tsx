import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePaperStore } from '../stores/paperStore';
import { useVocabStore } from '../stores/vocabStore';

export default function PaperList() {
  const { papers, isLoading, fetchPapers, uploadPaper, deletePaper } = usePaperStore();
  const { stats, fetchStats } = useVocabStore();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchPapers();
    fetchStats();
  }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      await uploadPaper(file);
    } catch (err: any) {
      alert(err.message || '上传失败');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDelete = async (id: string, title: string) => {
    if (confirm(`确定删除论文"${title}"？`)) {
      await deletePaper(id);
    }
  };

  const getStatusBadge = (status: string, processingStatus: string) => {
    if (processingStatus === 'processing') {
      return <span className="text-xs px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700">处理中</span>;
    }
    if (processingStatus === 'error') {
      return <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-700">处理失败</span>;
    }
    const labels: Record<string, string> = { unread: '未读', reading: '在读', finished: '已读' };
    const colors: Record<string, string> = {
      unread: 'bg-gray-100 text-gray-600',
      reading: 'bg-blue-100 text-blue-700',
      finished: 'bg-green-100 text-green-700',
    };
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${colors[status] || 'bg-gray-100'}`}>
        {labels[status] || status}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航 */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-lg font-bold text-gray-900">📚 论文阅读器</h1>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/vocab')}
              className="text-sm text-primary-600 hover:underline"
            >
              生词本
            </button>
            <button
              onClick={() => navigate('/review')}
              className="text-sm text-primary-600 hover:underline"
            >
              复习
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* 学习统计卡片 */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="card text-center">
              <div className="text-2xl font-bold text-primary-600">{stats.total}</div>
              <div className="text-xs text-gray-500 mt-1">总生词</div>
            </div>
            <div className="card text-center">
              <div className="text-2xl font-bold text-green-600">{stats.active}</div>
              <div className="text-xs text-gray-500 mt-1">学习中</div>
            </div>
            <div className="card text-center">
              <div className="text-2xl font-bold text-orange-500">{stats.dueToday}</div>
              <div className="text-xs text-gray-500 mt-1">今日待复习</div>
            </div>
            <div className="card text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.recentReviews}</div>
              <div className="text-xs text-gray-500 mt-1">7天复习</div>
            </div>
          </div>
        )}

        {/* 上传按钮 */}
        <div className="flex items-center gap-3">
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf"
            onChange={handleUpload}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="btn-primary flex items-center gap-2"
            disabled={uploading}
          >
            {uploading ? (
              <>
                <span className="animate-spin">⏳</span> 上传中...
              </>
            ) : (
              <>+ 上传论文</>
            )}
          </button>
          <span className="text-sm text-gray-500">支持 PDF 格式</span>
        </div>

        {/* 论文列表 */}
        <div className="space-y-3">
          {isLoading && papers.length === 0 && (
            <div className="text-center py-12 text-gray-500">加载中...</div>
          )}

          {!isLoading && papers.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <p className="text-lg mb-2">暂无论文</p>
              <p className="text-sm">点击上方按钮上传你的第一篇论文</p>
            </div>
          )}

          {papers.map((paper) => (
            <div
              key={paper.id}
              className="card hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => navigate(`/paper/${paper.id}`)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-gray-900 truncate">{paper.title}</h3>
                  <div className="flex items-center gap-2 mt-2">
                    {getStatusBadge(paper.status, paper.processingStatus)}
                    {paper.pageCount && (
                      <span className="text-xs text-gray-400">{paper.pageCount} 页</span>
                    )}
                    <span className="text-xs text-gray-400">
                      {new Date(paper.createdAt).toLocaleDateString('zh-CN')}
                    </span>
                  </div>
                  {paper.abstract && (
                    <p className="text-sm text-gray-500 mt-2 line-clamp-2">{paper.abstract}</p>
                  )}
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete(paper.id, paper.title);
                  }}
                  className="text-gray-400 hover:text-red-500 p-1 ml-2"
                  title="删除"
                >
                  🗑️
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
