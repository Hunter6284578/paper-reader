import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { usePaperStore } from '../stores/paperStore';
import { useVocabStore } from '../stores/vocabStore';
import { useReaderStore } from '../stores/readerStore';
import { useTextSelection } from '../hooks/useTextSelection';
import { useStatusBar } from '../hooks/useStatusBar';
import type { StructureSection } from '../types';

import ReaderHeader from '../components/reader/ReaderHeader';
import ReadingArea from '../components/reader/ReadingArea';
import ProgressBar from '../components/reader/ProgressBar';
import SettingsPanel from '../components/reader/SettingsPanel';
import TableOfContents from '../components/reader/TableOfContents';
import FloatingToolbar from '../components/reader/FloatingToolbar';
import ChatSidebar from '../components/reader/ChatSidebar';
import ChatBottomSheet from '../components/reader/ChatBottomSheet';

export default function PaperReader() {
  const { id } = useParams<{ id: string }>();
  const { currentPaper, highlights, fetchPaper, fetchHighlights, addHighlight, updatePaper } = usePaperStore();
  const { addVocab } = useVocabStore();
  const settings = useReaderStore((s) => s.settings);
  const showToc = useReaderStore((s) => s.showToc);
  const toggleToc = useReaderStore((s) => s.toggleToc);

  const [showChat, setShowChat] = useState(false);
  const [sections, setSections] = useState<StructureSection[]>([]);
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 1024);

  const containerRef = useRef<HTMLDivElement>(null);
  const { selection, clearSelection } = useTextSelection(containerRef);

  // 状态栏适配（Android）
  useStatusBar();

  // 响应式检测
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const handler = (e: MediaQueryListEvent) => setIsDesktop(e.matches);
    mq.addEventListener('change', handler);
    setIsDesktop(mq.matches);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // 加载论文数据
  useEffect(() => {
    if (id) {
      fetchPaper(id);
      fetchHighlights(id);
    }
  }, [id]);

  // 标记为在读
  useEffect(() => {
    if (currentPaper && currentPaper.status === 'unread') {
      updatePaper(currentPaper.id, { status: 'reading' });
    }
  }, [currentPaper]);

  // 处理高亮
  const handleHighlight = useCallback(async (color: string) => {
    if (!id || !selection) return;
    await addHighlight({
      paperId: id,
      pageNumber: null,
      paragraphId: selection.paragraphId,
      position: {
        mode: 'text',
        paragraphId: selection.paragraphId,
        startOffset: selection.startOffset,
        endOffset: selection.endOffset,
      } as any,
      type: 'highlight',
      color,
      comment: null,
      selectedText: selection.text,
    });
    clearSelection();
  }, [id, selection, addHighlight, clearSelection]);

  // 收藏生词
  const handleAddVocab = useCallback(async () => {
    if (!selection) return;
    const word = selection.text.split(/\s+/)[0].replace(/[^a-zA-Z]/g, '');
    if (!word) return;
    try {
      await addVocab(word, selection.text, id);
      alert(`已收藏单词: ${word}`);
    } catch (e: any) {
      alert(e.message || '收藏失败');
    }
    clearSelection();
  }, [selection, id, addVocab, clearSelection]);

  // 目录跳转
  const handleJump = useCallback((paragraphIndex: number) => {
    const container = containerRef.current;
    if (container && (container as any).__jumpToParagraph) {
      (container as any).__jumpToParagraph(paragraphIndex);
    }
  }, []);

  if (!currentPaper) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <p className="text-gray-500">加载中...</p>
      </div>
    );
  }

  const isDark = settings.theme === 'dark';
  const isSepia = settings.theme === 'sepia';

  const bgClass = isDark
    ? 'bg-gray-900 text-gray-100'
    : isSepia
    ? 'bg-[#f5f0e8] text-[#3d3529]'
    : 'bg-white text-gray-900';

  return (
    <div className={`h-screen flex flex-col transition-colors ${bgClass}`} data-reader-theme={settings.theme}>
      {/* 顶栏 */}
      <ReaderHeader
        title={currentPaper.title}
        isDesktop={isDesktop}
        showChat={showChat}
        onToggleChat={() => setShowChat(!showChat)}
        processingStatus={currentPaper.processingStatus}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* 阅读区域 */}
        <ReadingArea
          paperId={currentPaper.id}
          highlights={highlights}
          containerRef={containerRef}
          onSectionsLoaded={setSections}
        />

        {/* AI 问答 — 桌面端侧边栏 */}
        {isDesktop && showChat && (
          <ChatSidebar paperId={currentPaper.id} onClose={() => setShowChat(false)} />
        )}
      </div>

      {/* 进度条 */}
      <ProgressBar />

      {/* 浮动工具栏 */}
      {selection && (
        <FloatingToolbar
          selectedText={selection.text}
          rect={selection.rect}
          onHighlight={handleHighlight}
          onAddVocab={handleAddVocab}
          onClose={clearSelection}
        />
      )}

      {/* 设置面板 */}
      <SettingsPanel />

      {/* 目录 */}
      {showToc && (
        <TableOfContents
          sections={sections}
          onJump={handleJump}
          onClose={toggleToc}
        />
      )}

      {/* AI 问答 — 移动端底部弹窗 */}
      {!isDesktop && showChat && (
        <ChatBottomSheet paperId={currentPaper.id} onClose={() => setShowChat(false)} />
      )}
    </div>
  );
}
