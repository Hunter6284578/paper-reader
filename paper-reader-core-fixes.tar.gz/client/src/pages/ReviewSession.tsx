import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVocabStore } from '../stores/vocabStore';
import type { ReviewGrade } from '../types';

export default function ReviewSession() {
  const { reviewItems, isLoading, fetchReviewToday, submitReview } = useVocabStore();
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [completed, setCompleted] = useState(0);

  useEffect(() => {
    fetchReviewToday();
  }, []);

  const currentItem = reviewItems[currentIndex];

  const handleReview = async (grade: ReviewGrade) => {
    if (!currentItem) return;

    await submitReview(currentItem.id, grade);
    setFlipped(false);
    setCompleted((c) => c + 1);

    // 如果当前项被移除，调整索引
    if (currentIndex >= reviewItems.length - 1) {
      setCurrentIndex(Math.max(0, reviewItems.length - 2));
    }
  };

  const playAudio = (url: string) => {
    new Audio(url).play();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/vocab')} className="text-gray-600 hover:text-gray-900">
              ← 返回
            </button>
            <h1 className="text-lg font-bold text-gray-900">🧠 单词复习</h1>
          </div>
          <span className="text-sm text-gray-500">
            {completed} / {reviewItems.length + completed}
          </span>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-8">
        {isLoading && (
          <div className="text-center py-12 text-gray-500">加载中...</div>
        )}

        {!isLoading && reviewItems.length === 0 && (
          <div className="text-center py-12">
            <div className="text-5xl mb-4">🎉</div>
            <p className="text-lg font-medium text-gray-700">
              {completed > 0 ? '复习完成！' : '今日无需复习'}
            </p>
            <p className="text-sm text-gray-500 mt-2">
              {completed > 0 ? `已完成 ${completed} 个单词的复习` : '所有单词都还没到复习时间'}
            </p>
            <button
              onClick={() => navigate('/')}
              className="btn-primary mt-6"
            >
              返回首页
            </button>
          </div>
        )}

        {currentItem && (
          <div className="space-y-6">
            {/* 进度条 */}
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                style={{
                  width: `${((completed) / (reviewItems.length + completed)) * 100}%`,
                }}
              />
            </div>

            {/* 闪卡 */}
            <div
              className="flashcard-flip cursor-pointer"
              onClick={() => setFlipped(!flipped)}
            >
              <div className={`flashcard-flip-inner ${flipped ? 'flipped' : ''}`}>
                {/* 正面 - 单词 */}
                <div className="flashcard-front card min-h-[280px] flex flex-col items-center justify-center p-6">
                  <h2 className="text-3xl font-bold text-gray-900">{currentItem.word}</h2>
                  {currentItem.phonetic && (
                    <p className="text-lg text-gray-500 mt-2">{currentItem.phonetic}</p>
                  )}
                  {currentItem.audioUrl && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        playAudio(currentItem.audioUrl!);
                      }}
                      className="mt-3 text-primary-600 hover:text-primary-700 text-2xl"
                    >
                      🔊
                    </button>
                  )}
                  {currentItem.contextSentence && (
                    <p className="text-sm text-gray-400 mt-4 text-center italic">
                      "...{currentItem.contextSentence.slice(0, 100)}..."
                    </p>
                  )}
                  <p className="text-xs text-gray-400 mt-6">点击卡片查看释义</p>
                </div>

                {/* 背面 - 释义 */}
                <div className="flashcard-back card min-h-[280px] flex flex-col items-center justify-center p-6 absolute inset-0">
                  {currentItem.partOfSpeech && (
                    <span className="text-sm bg-gray-100 text-gray-600 px-3 py-1 rounded mb-3">
                      {currentItem.partOfSpeech}
                    </span>
                  )}
                  {currentItem.definitionEn && (
                    <p className="text-base text-gray-800 text-center mb-2">
                      {currentItem.definitionEn}
                    </p>
                  )}
                  {currentItem.definitionCn && (
                    <p className="text-base text-gray-600 text-center">
                      {currentItem.definitionCn}
                    </p>
                  )}
                  {currentItem.exampleSentence && (
                    <p className="text-sm text-gray-400 italic mt-4 text-center">
                      "{currentItem.exampleSentence}"
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* 评分按钮 */}
            {flipped && (
              <div className="grid grid-cols-4 gap-2">
                <button
                  onClick={() => handleReview('forgot')}
                  className="py-3 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 active:bg-red-700"
                >
                  忘记
                </button>
                <button
                  onClick={() => handleReview('hard')}
                  className="py-3 bg-orange-500 text-white rounded-lg text-sm font-medium hover:bg-orange-600 active:bg-orange-700"
                >
                  困难
                </button>
                <button
                  onClick={() => handleReview('good')}
                  className="py-3 bg-green-500 text-white rounded-lg text-sm font-medium hover:bg-green-600 active:bg-green-700"
                >
                  记得
                </button>
                <button
                  onClick={() => handleReview('easy')}
                  className="py-3 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 active:bg-blue-700"
                >
                  简单
                </button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
