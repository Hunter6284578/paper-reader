import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useVocabStore } from '../stores/vocabStore';

export default function VocabBook() {
  const { vocabItems, isLoading, fetchVocabList, deleteVocab } = useVocabStore();
  const navigate = useNavigate();

  useEffect(() => {
    fetchVocabList();
  }, []);

  const handleDelete = async (id: number, word: string) => {
    if (confirm(`确定删除单词"${word}"？`)) {
      await deleteVocab(id);
    }
  };

  const playAudio = (url: string) => {
    new Audio(url).play();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate('/')} className="text-gray-600 hover:text-gray-900">
              ← 返回
            </button>
            <h1 className="text-lg font-bold text-gray-900">📖 生词本</h1>
            <span className="text-sm text-gray-500">({vocabItems.length} 词)</span>
          </div>
          <button
            onClick={() => navigate('/review')}
            className="btn-primary text-sm"
          >
            开始复习
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-6">
        {isLoading && vocabItems.length === 0 && (
          <div className="text-center py-12 text-gray-500">加载中...</div>
        )}

        {!isLoading && vocabItems.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <p className="text-lg mb-2">生词本为空</p>
            <p className="text-sm">阅读论文时选中单词即可收藏</p>
          </div>
        )}

        <div className="space-y-2">
          {vocabItems.map((item) => (
            <div key={item.id} className="card flex items-start gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-lg text-gray-900">{item.word}</span>
                  {item.phonetic && (
                    <span className="text-sm text-gray-500">{item.phonetic}</span>
                  )}
                  {item.audioUrl && (
                    <button
                      onClick={() => playAudio(item.audioUrl!)}
                      className="text-primary-600 hover:text-primary-700"
                    >
                      🔊
                    </button>
                  )}
                  {item.partOfSpeech && (
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                      {item.partOfSpeech}
                    </span>
                  )}
                </div>

                {item.definitionEn && (
                  <p className="text-sm text-gray-700 mt-1">{item.definitionEn}</p>
                )}
                {item.definitionCn && (
                  <p className="text-sm text-gray-500 mt-0.5">{item.definitionCn}</p>
                )}
                {item.exampleSentence && (
                  <p className="text-sm text-gray-400 italic mt-1">
                    "{item.exampleSentence}"
                  </p>
                )}
                {item.contextSentence && (
                  <p className="text-xs text-blue-500 mt-1">
                    📄 来源: "{item.contextSentence.slice(0, 80)}..."
                  </p>
                )}

                {/* 复习状态 */}
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-xs text-gray-400">
                    间隔: {Math.round(item.intervalDays)}天
                  </span>
                  <span className="text-xs text-gray-400">
                    复习: {item.totalReviews}次
                  </span>
                  <span className="text-xs text-gray-400">
                    下次: {new Date(item.dueDate).toLocaleDateString('zh-CN')}
                  </span>
                </div>
              </div>

              <button
                onClick={() => handleDelete(item.id, item.word)}
                className="text-gray-400 hover:text-red-500 p-1 shrink-0"
              >
                🗑️
              </button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
