import type { PageImage, Paragraph, StructureSection, TranslationResult } from '../types';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

function getToken(): string | null {
  return localStorage.getItem('token');
}

export function setToken(token: string): void {
  localStorage.setItem('token', token);
}

export function clearToken(): void {
  localStorage.removeItem('token');
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // 不自动设置 Content-Type，让浏览器处理 multipart/form-data
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: '请求失败' }));
    throw new Error(error.error || `HTTP ${response.status}`);
  }

  return response.json();
}

export const api = {
  get: <T>(path: string) => request<T>(path),

  post: <T>(path: string, body?: unknown) =>
    request<T>(path, {
      method: 'POST',
      body: body instanceof FormData ? body : JSON.stringify(body),
    }),

  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),

  delete: <T>(path: string) =>
    request<T>(path, { method: 'DELETE' }),
};

// ============================================================
// 阅读 API
// ============================================================

export async function fetchStructure(paperId: string) {
  return api.get<{
    sections: StructureSection[];
    totalParagraphs: number;
    paragraphStatus: string;
  }>(`/reading/${paperId}/structure`);
}

export async function fetchParagraphs(paperId: string, offset: number, limit: number = 20) {
  return api.get<{
    paragraphs: Paragraph[];
    total: number;
    offset: number;
    limit: number;
  }>(`/reading/${paperId}/paragraphs?offset=${offset}&limit=${limit}`);
}

export async function translateParagraphs(paperId: string, ids: number[], mode: 'paragraph' | 'sentence' = 'paragraph') {
  return api.post<{ translations: TranslationResult[] }>(`/reading/${paperId}/translate`, { ids, mode });
}

export async function fetchPageImages(paperId: string) {
  return api.get<{ images: PageImage[] }>(`/images/${paperId}`);
}
