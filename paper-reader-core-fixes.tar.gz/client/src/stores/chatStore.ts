import { create } from 'zustand';
import type { ChatMessage, ChatReference } from '../types';
import { api } from '../services/api';

const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

interface ChatState {
  messages: ChatMessage[];
  isStreaming: boolean;
  streamContent: string;
  currentReferences: ChatReference[];
  fetchHistory: (paperId: string) => Promise<void>;
  sendMessage: (paperId: string, question: string) => Promise<void>;
  clearHistory: (paperId: string) => Promise<void>;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  isStreaming: false,
  streamContent: '',
  currentReferences: [],

  fetchHistory: async (paperId) => {
    try {
      const res = await api.get<{ messages: ChatMessage[] }>(`/chat/history/${paperId}`);
      set({ messages: res.messages });
    } catch (e) {
      console.error('获取聊天历史失败:', e);
    }
  },

  sendMessage: async (paperId, question) => {
    set({ isStreaming: true, streamContent: '', currentReferences: [] });

    // 添加用户消息到列表
    const userMsg: ChatMessage = {
      id: Date.now(),
      paperId,
      role: 'user',
      content: question,
      references: [],
      createdAt: new Date().toISOString(),
    };
    set((state) => ({ messages: [...state.messages, userMsg] }));

    const response = await fetch(`${API_BASE}/chat/ask`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ paperId, question }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: '请求失败' }));
      set({ isStreaming: false });
      throw new Error(error.error || 'AI 问答失败');
    }

    const reader = response.body?.getReader();
    if (!reader) {
      set({ isStreaming: false });
      return;
    }

    const decoder = new TextDecoder();
    let fullContent = '';
    let references: ChatReference[] = [];

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const text = decoder.decode(value, { stream: true });
      const lines = text.split('\n');

      for (const line of lines) {
        if (line.startsWith('event: chunk')) {
          continue;
        }
        if (line.startsWith('data:')) {
          const data = line.slice(5).trim();
          if (!data) continue;

          // 尝试解析为 JSON（done/error 事件）
          try {
            const parsed = JSON.parse(data);
            if (parsed.references) {
              references = parsed.references;
            }
            if (parsed.error) {
              set({ isStreaming: false });
              throw new Error(parsed.error);
            }
          } catch {
            // 普通文本块
            fullContent += data;
            set({ streamContent: fullContent });
          }
        }
      }
    }

    // 添加助手回复到消息列表
    const assistantMsg: ChatMessage = {
      id: Date.now() + 1,
      paperId,
      role: 'assistant',
      content: fullContent,
      references,
      createdAt: new Date().toISOString(),
    };

    set((state) => ({
      messages: [...state.messages, assistantMsg],
      isStreaming: false,
      streamContent: '',
      currentReferences: references,
    }));
  },

  clearHistory: async (paperId) => {
    await api.delete(`/chat/history/${paperId}`);
    set({ messages: [] });
  },
}));
