import { create } from 'zustand';
import type { VocabItem, VocabStats, ReviewGrade } from '../types';
import { api } from '../services/api';

interface VocabState {
  vocabItems: VocabItem[];
  reviewItems: VocabItem[];
  stats: VocabStats | null;
  isLoading: boolean;
  error: string | null;
  fetchVocabList: () => Promise<void>;
  fetchReviewToday: () => Promise<void>;
  fetchStats: () => Promise<void>;
  addVocab: (word: string, context?: string, paperId?: string) => Promise<VocabItem>;
  submitReview: (vocabId: number, grade: ReviewGrade) => Promise<void>;
  deleteVocab: (id: number) => Promise<void>;
}

export const useVocabStore = create<VocabState>((set) => ({
  vocabItems: [],
  reviewItems: [],
  stats: null,
  isLoading: false,
  error: null,

  fetchVocabList: async () => {
    set({ isLoading: true });
    try {
      const res = await api.get<{ vocabItems: VocabItem[] }>('/vocab');
      set({ vocabItems: res.vocabItems, isLoading: false });
    } catch (e: any) {
      set({ error: e.message, isLoading: false });
    }
  },

  fetchReviewToday: async () => {
    set({ isLoading: true });
    try {
      const res = await api.get<{ reviewItems: VocabItem[] }>('/vocab/review/today');
      set({ reviewItems: res.reviewItems, isLoading: false });
    } catch (e: any) {
      set({ error: e.message, isLoading: false });
    }
  },

  fetchStats: async () => {
    try {
      const res = await api.get<{ stats: VocabStats }>('/vocab/stats');
      set({ stats: res.stats });
    } catch (e) {
      console.error('获取统计失败:', e);
    }
  },

  addVocab: async (word, context, paperId) => {
    const res = await api.post<{ vocabItem: VocabItem }>('/vocab/add', {
      word,
      contextSentence: context,
      sourcePaperId: paperId,
    });
    set((state) => ({ vocabItems: [res.vocabItem, ...state.vocabItems] }));
    return res.vocabItem;
  },

  submitReview: async (vocabId, grade) => {
    const res = await api.post<{ vocabItem: VocabItem }>(`/vocab/review/${vocabId}`, { grade });
    set((state) => ({
      reviewItems: state.reviewItems.filter((v) => v.id !== vocabId),
      vocabItems: state.vocabItems.map((v) => (v.id === vocabId ? res.vocabItem : v)),
    }));
  },

  deleteVocab: async (id) => {
    await api.delete(`/vocab/${id}`);
    set((state) => ({
      vocabItems: state.vocabItems.filter((v) => v.id !== id),
    }));
  },
}));
