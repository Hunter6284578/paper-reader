import { config } from 'dotenv';
config();

export const ENV = {
  PORT: parseInt(process.env.PORT || '3000', 10),
  NODE_ENV: process.env.NODE_ENV || 'development',
  DATA_DIR: process.env.DATA_DIR || './data',
  DB_PATH: process.env.DB_PATH || './data/db/app.db',
  PAPERS_DIR: process.env.PAPERS_DIR || './data/papers',
  UPLOADS_DIR: process.env.UPLOADS_DIR || './data/uploads',

  JWT_SECRET: process.env.JWT_SECRET || 'dev-secret-change-in-production',
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',

  DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY || '',
  DEEPSEEK_BASE_URL: process.env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com',
  DEEPSEEK_MODEL: process.env.DEEPSEEK_MODEL || 'deepseek-chat',

  SILICONFLOW_API_KEY: process.env.SILICONFLOW_API_KEY || '',
  SILICONFLOW_BASE_URL: process.env.SILICONFLOW_BASE_URL || 'https://api.siliconflow.cn/v1',
  EMBEDDING_MODEL: process.env.EMBEDDING_MODEL || 'BAAI/bge-m3',
  EMBEDDING_DIM: parseInt(process.env.EMBEDDING_DIM || '1024', 10),

  DICT_API_URL: process.env.DICT_API_URL || 'https://api.dictionaryapi.dev/api/v2/entries/en',
} as const;
