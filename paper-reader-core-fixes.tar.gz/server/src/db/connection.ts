import Database, { type Database as DatabaseType } from 'better-sqlite3';
import { drizzle } from 'drizzle-orm/better-sqlite3';
import { mkdirSync } from 'fs';
import { dirname } from 'path';
import { ENV } from '../config.js';
import * as schema from './schema.js';

// 确保数据目录存在
mkdirSync(dirname(ENV.DB_PATH), { recursive: true });

const sqlite: DatabaseType = new Database(ENV.DB_PATH);

// 启用 WAL 模式提升并发性能
sqlite.pragma('journal_mode = WAL');
sqlite.pragma('foreign_keys = ON');

// 兼容已有部署的数据卷。drizzle-kit push 会把运行时创建的 FTS5 表误判为
// 待删除表，因此核心新增结构采用幂等、只增不删的启动迁移。
function hasTable(name: string): boolean {
  return Boolean(sqlite.prepare(
    `SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?`
  ).get(name));
}

function hasColumn(table: string, column: string): boolean {
  return (sqlite.pragma(`table_info(${table})`) as Array<{ name: string }>)
    .some((entry) => entry.name === column);
}

const migrateCoreFeatures = sqlite.transaction(() => {
  if (hasTable('papers') && !hasColumn('papers', 'paragraph_status')) {
    sqlite.exec(`ALTER TABLE papers ADD COLUMN paragraph_status TEXT NOT NULL DEFAULT 'pending'`);
  }

  if (hasTable('paragraphs') && !hasColumn('paragraphs', 'processed_content')) {
    sqlite.exec(`ALTER TABLE paragraphs ADD COLUMN processed_content TEXT`);
  }

  if (hasTable('highlights') && !hasColumn('highlights', 'paragraph_id')) {
    sqlite.exec(`ALTER TABLE highlights ADD COLUMN paragraph_id INTEGER`);
  }

  if (hasTable('papers')) {
    sqlite.exec(`
      CREATE TABLE IF NOT EXISTS page_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paper_id TEXT NOT NULL REFERENCES papers(id) ON DELETE CASCADE,
        page_number INTEGER NOT NULL,
        image_path TEXT NOT NULL,
        width INTEGER,
        height INTEGER,
        file_size INTEGER,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE UNIQUE INDEX IF NOT EXISTS idx_page_images_paper_page
        ON page_images (paper_id, page_number);
      CREATE INDEX IF NOT EXISTS idx_page_images_paper
        ON page_images (paper_id);
    `);
  }
});

migrateCoreFeatures();

export const db = drizzle(sqlite, { schema });
export { sqlite };
