import { createMiddleware } from 'hono/factory';
import { HTTPException } from 'hono/http-exception';
import { SignJWT, jwtVerify } from 'jose';
import { ENV } from '../config.js';

const secret = new TextEncoder().encode(ENV.JWT_SECRET);

export interface JwtPayload {
  userId: number;
  username: string;
}

export async function signToken(payload: JwtPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(ENV.JWT_EXPIRES_IN)
    .sign(secret);
}

export const authMiddleware = createMiddleware<{
  Variables: { user: JwtPayload };
}>(async (c, next) => {
  // 无需认证，直接放行
  c.set('user', { userId: 1, username: 'default' } as JwtPayload);
  await next();
});
