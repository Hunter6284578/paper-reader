/**
 * 阅读 API 路由
 * 提供论文结构化段落查询、翻译等功能
 */

import { Hono } from 'hono';
import { z } from 'zod';
import { zValidator } from '@hono/zod-validator';
import { eq, and, gte, lt, asc, inArray } from 'drizzle-orm';
import { db } from '../db/connection.js';
import { paragraphs, sentences, translations, papers } from '../db/schema.js';
import { authMiddleware } from '../middleware/auth.js';
import { translateParagraphs, translateSentences } from '../services/translationService.js';

const readingRoute = new Hono();

// 获取论文结构目录
readingRoute.get('/:paperId/structure', authMiddleware, async (c) => {
  const paperId = c.req.param('paperId');

  const paper = db.select().from(papers).where(eq(papers.id, paperId)).get();
  if (!paper) {
    return c.json({ error: '论文不存在' }, 404);
  }

  // 按 sectionTitle 分组统计
  const allParagraphs = db
    .select({
      sectionTitle: paragraphs.sectionTitle,
      paragraphIndex: paragraphs.paragraphIndex,
    })
    .from(paragraphs)
    .where(eq(paragraphs.paperId, paperId))
    .orderBy(asc(paragraphs.paragraphIndex))
    .all();

  // 构建目录结构
  const sections: Array<{
    sectionTitle: string;
    paragraphCount: number;
    startIndex: number;
  }> = [];

  let currentSection = '';
  let count = 0;
  let startIndex = 0;

  for (const p of allParagraphs) {
    const title = p.sectionTitle || 'Full Text';
    if (title !== currentSection) {
      if (currentSection) {
        sections.push({ sectionTitle: currentSection, paragraphCount: count, startIndex });
      }
      currentSection = title;
      count = 1;
      startIndex = p.paragraphIndex;
    } else {
      count++;
    }
  }
  if (currentSection) {
    sections.push({ sectionTitle: currentSection, paragraphCount: count, startIndex });
  }

  return c.json({
    sections,
    totalParagraphs: allParagraphs.length,
    paragraphStatus: paper.paragraphStatus,
  });
});

// 分页获取段落列表（含句子 + 已有翻译）
readingRoute.get('/:paperId/paragraphs', authMiddleware, async (c) => {
  const paperId = c.req.param('paperId');
  const offset = parseInt(c.req.query('offset') || '0', 10);
  const limit = Math.min(parseInt(c.req.query('limit') || '20', 10), 50);

  // 获取段落
  const paraList = db
    .select()
    .from(paragraphs)
    .where(
      and(
        eq(paragraphs.paperId, paperId),
        gte(paragraphs.paragraphIndex, offset),
        lt(paragraphs.paragraphIndex, offset + limit)
      )
    )
    .orderBy(asc(paragraphs.paragraphIndex))
    .all();

  if (paraList.length === 0) {
    return c.json({ paragraphs: [], total: 0, offset, limit });
  }

  const paraIds = paraList.map((p) => p.id);

  // 获取句子
  const sentenceList = db
    .select()
    .from(sentences)
    .where(inArray(sentences.paragraphId, paraIds))
    .orderBy(asc(sentences.paragraphId), asc(sentences.sentenceIndex))
    .all();

  // 获取已有翻译（段落级）
  const paraTranslations = db
    .select()
    .from(translations)
    .where(
      and(
        eq(translations.sourceType, 'paragraph'),
        inArray(translations.sourceId, paraIds)
      )
    )
    .all();

  // 获取已有翻译（句子级）
  const sentenceIds = sentenceList.map((s) => s.id);
  let sentTranslations: typeof translations.$inferSelect[] = [];
  if (sentenceIds.length > 0) {
    sentTranslations = db
      .select()
      .from(translations)
      .where(
        and(
          eq(translations.sourceType, 'sentence'),
          inArray(translations.sourceId, sentenceIds)
        )
      )
      .all();
  }

  // 构建响应
  const sentTransMap = new Map(sentTranslations.map((t) => [t.sourceId, t.translatedText]));
  const paraTransMap = new Map(paraTranslations.map((t) => [t.sourceId, t.translatedText]));

  const sentByPara = new Map<number, Array<{ id: number; sentenceIndex: number; content: string }>>();
  for (const s of sentenceList) {
    if (!sentByPara.has(s.paragraphId)) {
      sentByPara.set(s.paragraphId, []);
    }
    sentByPara.get(s.paragraphId)!.push({
      id: s.id,
      sentenceIndex: s.sentenceIndex,
      content: s.content,
    });
  }

  const result = paraList.map((p) => {
    const paraSentences = sentByPara.get(p.id) || [];
    const sentenceTranslations: Record<number, string> = {};
    for (const s of paraSentences) {
      const trans = sentTransMap.get(s.id);
      if (trans) sentenceTranslations[s.id] = trans;
    }

    return {
      id: p.id,
      sectionTitle: p.sectionTitle,
      paragraphIndex: p.paragraphIndex,
      content: p.content,
      processedContent: p.processedContent || null,
      charCount: p.charCount,
      sentences: paraSentences,
      translation: paraTransMap.get(p.id) || null,
      sentenceTranslations,
    };
  });

  // 获取总段落数
  const totalResult = db
    .select({ count: paragraphs.id })
    .from(paragraphs)
    .where(eq(paragraphs.paperId, paperId))
    .all();

  return c.json({
    paragraphs: result,
    total: totalResult.length,
    offset,
    limit,
  });
});

// 批量翻译
const translateSchema = z.object({
  ids: z.array(z.number()).min(1).max(20),
  mode: z.enum(['paragraph', 'sentence']),
});

readingRoute.post('/:paperId/translate', authMiddleware, zValidator('json', translateSchema), async (c) => {
  const paperId = c.req.param('paperId');
  const { ids, mode } = c.req.valid('json');

  try {
    let results;
    if (mode === 'paragraph') {
      results = await translateParagraphs(paperId, ids);
    } else {
      results = await translateSentences(paperId, ids);
    }

    return c.json({ translations: results });
  } catch (e: any) {
    console.error('[翻译API] 失败:', e);
    return c.json({ error: e.message || '翻译失败' }, 500);
  }
});

export { readingRoute };
