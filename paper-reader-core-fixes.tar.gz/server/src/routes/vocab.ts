import { Hono } from 'hono';
import { z } from 'zod';
import { zValidator } from '@hono/zod-validator';
import { eq, and, lte, desc, sql } from 'drizzle-orm';
import { db } from '../db/connection.js';
import { vocabItems, reviewLogs } from '../db/schema.js';
import { authMiddleware } from '../middleware/auth.js';
import { lookupWord } from '../services/dictionary.js';
import { sm2Schedule, REVIEW_QUALITY_MAP, type ReviewGrade } from '../services/sm2Scheduler.js';
import { chatCompletion } from '../services/llmService.js';
import { ENV } from '../config.js';

const vocabRoute = new Hono();

// 获取生词列表
vocabRoute.get('/', authMiddleware, async (c) => {
  const status = c.req.query('status') || 'active';
  const list = db.select()
    .from(vocabItems)
    .where(eq(vocabItems.status, status))
    .orderBy(desc(vocabItems.createdAt))
    .all();

  return c.json({ vocabItems: list });
});

// 获取今日复习任务
vocabRoute.get('/review/today', authMiddleware, async (c) => {
  const now = new Date().toISOString();
  const list = db.select()
    .from(vocabItems)
    .where(and(
      eq(vocabItems.status, 'active'),
      lte(vocabItems.dueDate, now)
    ))
    .orderBy(vocabItems.dueDate)
    .all();

  return c.json({
    reviewItems: list,
    totalCount: list.length,
  });
});

// 添加生词
const addSchema = z.object({
  word: z.string().min(1),
  contextSentence: z.string().optional(),
  sourcePaperId: z.string().optional(),
});

vocabRoute.post('/add', authMiddleware, zValidator('json', addSchema), async (c) => {
  const data = c.req.valid('json');
  const word = data.word.toLowerCase().trim();

  // 检查是否已存在
  const existing = db.select().from(vocabItems).where(eq(vocabItems.word, word)).get();
  if (existing) {
    return c.json({ error: '该单词已在生词本中', vocabItem: existing }, 409);
  }

  // 查询词典
  const dictResult = await lookupWord(word);

  // 可选：获取中文释义
  let definitionCn: string | null = null;
  if (ENV.DEEPSEEK_API_KEY && dictResult?.definitionEn) {
    try {
      definitionCn = await chatCompletion([
        {
          role: 'system',
          content: '你是一位英语词典翻译。请将以下英文单词的释义翻译成简洁的中文，只需给出中文翻译，不需要其他内容。',
        },
        {
          role: 'user',
          content: `单词: ${word}\n英文释义: ${dictResult.definitionEn}`,
        },
      ], { maxTokens: 100 });
    } catch (e) {
      console.warn('[生词] 中文释义获取失败:', e);
    }
  }

  // 写入数据库
  const vocabItem = db.insert(vocabItems).values({
    word,
    phonetic: dictResult?.phonetic,
    audioUrl: dictResult?.audioUrl,
    partOfSpeech: dictResult?.partOfSpeech,
    definitionEn: dictResult?.definitionEn,
    definitionCn,
    exampleSentence: dictResult?.exampleSentence,
    sourcePaperId: data.sourcePaperId || null,
    contextSentence: data.contextSentence || null,
  }).returning().get();

  return c.json({ vocabItem }, 201);
});

// 提交复习结果
const reviewSchema = z.object({
  grade: z.enum(['forgot', 'hard', 'good', 'easy']),
  responseTimeMs: z.number().optional(),
});

vocabRoute.post('/review/:id', authMiddleware, zValidator('json', reviewSchema), async (c) => {
  const id = parseInt(c.req.param('id'), 10);
  const { grade, responseTimeMs } = c.req.valid('json');

  const vocab = db.select().from(vocabItems).where(eq(vocabItems.id, id)).get();
  if (!vocab) {
    return c.json({ error: '生词不存在' }, 404);
  }

  const quality = REVIEW_QUALITY_MAP[grade];
  const result = sm2Schedule(
    {
      repetitions: vocab.repetitions,
      intervalDays: vocab.intervalDays,
      easeFactor: vocab.easeFactor,
    },
    quality
  );

  // 更新生词状态
  const updated = db.update(vocabItems)
    .set({
      repetitions: result.repetitions,
      intervalDays: result.intervalDays,
      easeFactor: result.easeFactor,
      dueDate: result.dueDate.toISOString(),
      lastReviewAt: new Date().toISOString(),
      totalReviews: vocab.totalReviews + 1,
      correctReviews: vocab.correctReviews + (quality >= 3 ? 1 : 0),
    })
    .where(eq(vocabItems.id, id))
    .returning()
    .get();

  // 记录复习日志
  db.insert(reviewLogs).values({
    vocabId: id,
    quality,
    prevInterval: vocab.intervalDays,
    newInterval: result.intervalDays,
    prevEaseFactor: vocab.easeFactor,
    newEaseFactor: result.easeFactor,
    responseTimeMs,
  }).run();

  return c.json({ vocabItem: updated });
});

// 删除生词
vocabRoute.delete('/:id', authMiddleware, async (c) => {
  const id = parseInt(c.req.param('id'), 10);
  db.delete(vocabItems).where(eq(vocabItems.id, id)).run();
  return c.json({ success: true });
});

// 获取学习统计
vocabRoute.get('/stats', authMiddleware, async (c) => {
  const total = db.select({ count: sql<number>`count(*)` })
    .from(vocabItems).get()?.count || 0;

  const active = db.select({ count: sql<number>`count(*)` })
    .from(vocabItems)
    .where(eq(vocabItems.status, 'active'))
    .get()?.count || 0;

  const mastered = db.select({ count: sql<number>`count(*)` })
    .from(vocabItems)
    .where(eq(vocabItems.status, 'mastered'))
    .get()?.count || 0;

  const now = new Date().toISOString();
  const dueToday = db.select({ count: sql<number>`count(*)` })
    .from(vocabItems)
    .where(and(
      eq(vocabItems.status, 'active'),
      lte(vocabItems.dueDate, now)
    ))
    .get()?.count || 0;

  // 最近7天复习数
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const recentReviews = db.select({ count: sql<number>`count(*)` })
    .from(reviewLogs)
    .where(sql`reviewed_at >= ${sevenDaysAgo.toISOString()}`)
    .get()?.count || 0;

  return c.json({
    stats: { total, active, mastered, dueToday, recentReviews },
  });
});

export { vocabRoute };
