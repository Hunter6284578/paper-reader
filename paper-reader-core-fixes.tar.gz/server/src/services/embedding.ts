import { ENV } from '../config.js';

const BATCH_SIZE = 8;

/**
 * 批量获取文本的 Embedding 向量
 * 使用 SiliconFlow API（兼容 OpenAI 格式）
 */
export async function getEmbeddings(texts: string[]): Promise<number[][]> {
  const results: number[][] = [];

  for (let i = 0; i < texts.length; i += BATCH_SIZE) {
    const batch = texts.slice(i, i + BATCH_SIZE);
    const embeddings = await requestEmbedding(batch);
    results.push(...embeddings);

    // 限流：每批之间等待 200ms（避免触发 API 限流）
    if (i + BATCH_SIZE < texts.length) {
      await sleep(200);
    }
  }

  return results;
}

/**
 * 获取单条文本的 Embedding
 */
export async function getSingleEmbedding(text: string): Promise<number[]> {
  const [embedding] = await requestEmbedding([text]);
  return embedding;
}

async function requestEmbedding(texts: string[]): Promise<number[][]> {
  const response = await fetch(`${ENV.SILICONFLOW_BASE_URL}/embeddings`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${ENV.SILICONFLOW_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: ENV.EMBEDDING_MODEL,
      input: texts,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Embedding API 错误 (${response.status}): ${error}`);
  }

  const data = await response.json() as {
    data: Array<{ embedding: number[]; index: number }>;
  };

  // 按 index 排序确保顺序正确
  return data.data
    .sort((a, b) => a.index - b.index)
    .map((d) => d.embedding);
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
