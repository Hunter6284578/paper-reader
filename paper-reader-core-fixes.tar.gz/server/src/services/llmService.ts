import { ENV } from '../config.js';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface StreamChunk {
  content: string;
  done: boolean;
}

/**
 * 调用 DeepSeek API 进行流式问答
 */
export async function streamChat(
  messages: ChatMessage[],
  onChunk: (chunk: StreamChunk) => void
): Promise<void> {
  const response = await fetch(`${ENV.DEEPSEEK_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${ENV.DEEPSEEK_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: ENV.DEEPSEEK_MODEL,
      messages,
      stream: true,
      temperature: 0.7,
      max_tokens: 2000,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`DeepSeek API 错误 (${response.status}): ${error}`);
  }

  const reader = response.body?.getReader();
  if (!reader) throw new Error('无法读取响应流');

  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || !trimmed.startsWith('data: ')) continue;

      const data = trimmed.slice(6);
      if (data === '[DONE]') {
        onChunk({ content: '', done: true });
        return;
      }

      try {
        const parsed = JSON.parse(data) as {
          choices?: Array<{ delta?: { content?: string } }>;
        };
        const content = parsed.choices?.[0]?.delta?.content || '';
        if (content) {
          onChunk({ content, done: false });
        }
      } catch {
        // 跳过解析失败的行
      }
    }
  }

  onChunk({ content: '', done: true });
}

/**
 * 构建 RAG 问答的 system prompt
 */
export function buildRAGSystemPrompt(
  contexts: Array<{ content: string; sectionTitle: string | null; index: number }>
): string {
  const contextText = contexts
    .map((c, i) => {
      const section = c.sectionTitle ? ` [${c.sectionTitle}]` : '';
      return `[${i + 1}]${section}\n${c.content}`;
    })
    .join('\n\n---\n\n');

  return `你是一位专业的学术论文解读助手。请严格基于以下提供的论文内容来回答用户问题。

重要规则：
1. 只根据提供的论文片段回答问题，不要编造论文中不存在的内容
2. 如果论文内容中没有相关信息，请明确告知用户"论文中未涉及此内容"
3. 回答时请引用对应的片段编号 [1][2] 等
4. 用清晰易懂的语言解释，必要时可以使用中文

相关论文片段：

${contextText}`;
}

/**
 * 非流式调用（用于获取中文释义等简短回复）
 */
export async function chatCompletion(
  messages: ChatMessage[],
  options?: { maxTokens?: number; temperature?: number }
): Promise<string> {
  const response = await fetch(`${ENV.DEEPSEEK_BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${ENV.DEEPSEEK_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: ENV.DEEPSEEK_MODEL,
      messages,
      stream: false,
      temperature: options?.temperature ?? 0.3,
      max_tokens: options?.maxTokens ?? 500,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`DeepSeek API 错误 (${response.status}): ${error}`);
  }

  const data = await response.json() as {
    choices: Array<{ message: { content: string } }>;
  };

  return data.choices[0]?.message?.content || '';
}
