import { readFileSync } from 'fs';
import { join } from 'path';
import { eq } from 'drizzle-orm';
import pdfParse from 'pdf-parse';
import { db, sqlite } from '../db/connection.js';
import { papers, chunks, paragraphs, sentences } from '../db/schema.js';
import { ENV } from '../config.js';
import { splitIntoChunks } from './chunker.js';
import { getEmbeddings } from './embedding.js';
import { splitIntoStructuredText } from './paragraphSplitter.js';
import { detectFormulas } from './formulaDetector.js';
import { renderPageImages } from './pageImageRenderer.js';

/**
 * 异步处理论文：提取文本 → 分块 → 向量化 → 存储
 */
export async function processPaperAsync(paperId: string): Promise<void> {
  console.log(`[PDF处理] 开始处理论文: ${paperId}`);

  try {
    const paper = db.select().from(papers).where(eq(papers.id, paperId)).get();
    if (!paper) {
      console.error(`[PDF处理] 论文不存在: ${paperId}`);
      return;
    }

    // 1. 提取 PDF 文本
    const filePath = join(ENV.PAPERS_DIR, paper.filePath);
    const pdfBuffer = readFileSync(filePath);
    const pdfData = await pdfParse(pdfBuffer);

    const fullText = pdfData.text;
    const pageCount = pdfData.numpages;

    // 更新页数
    db.update(papers).set({ pageCount }).where(eq(papers.id, paperId)).run();

    console.log(`[PDF处理] 提取完成: ${pageCount} 页, ${fullText.length} 字符`);

    // 2. 文本分块
    const chunkList = splitIntoChunks(fullText);
    console.log(`[PDF处理] 分块完成: ${chunkList.length} 个块`);

    // 3. 批量获取 Embedding（如果配置了 API Key）
    let embeddings: number[][] = [];
    if (ENV.SILICONFLOW_API_KEY) {
      try {
        const texts = chunkList.map((c) => c.content);
        embeddings = await getEmbeddings(texts);
        console.log(`[PDF处理] 向量化完成: ${embeddings.length} 个向量`);
      } catch (e) {
        console.warn('[PDF处理] 向量化失败，跳过:', e);
      }
    }

    // 4. 写入数据库
    db.delete(chunks).where(eq(chunks.paperId, paperId)).run();

    // 使用 sqlite 原生事务
    const insertStmt = sqlite.prepare(`
      INSERT INTO chunks (paper_id, chunk_index, content, section_title, page_number, token_count, embedding, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
    `);

    const insertAll = sqlite.transaction(() => {
      for (let i = 0; i < chunkList.length; i++) {
        insertStmt.run(
          paperId,
          i,
          chunkList[i].content,
          chunkList[i].sectionTitle,
          chunkList[i].pageNumber,
          chunkList[i].tokenCount,
          embeddings[i] ? JSON.stringify(embeddings[i]) : null
        );
      }
    });

    insertAll();

    // 5. 创建 FTS5 虚拟表（如果不存在）
    try {
      sqlite.exec(`
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
          content, section_title,
          content='chunks', content_rowid='id',
          tokenize='porter unicode61'
        )
      `);
      // 重建 FTS 索引
      sqlite.exec(`INSERT INTO chunks_fts(chunks_fts) VALUES('rebuild')`);
    } catch (e) {
      console.warn('[PDF处理] FTS 索引创建跳过:', e);
    }

    // 6. 段落拆分 → 写入 paragraphs + sentences 表
    try {
      console.log(`[PDF处理] 开始段落拆分...`);
      db.update(papers).set({ paragraphStatus: 'processing' }).where(eq(papers.id, paperId)).run();

      // 清空旧数据
      db.delete(sentences).where(eq(sentences.paperId, paperId)).run();
      db.delete(paragraphs).where(eq(paragraphs.paperId, paperId)).run();

      const structured = splitIntoStructuredText(fullText);
      let globalParaIndex = 0;

      const insertPara = sqlite.prepare(`
        INSERT INTO paragraphs (paper_id, section_title, paragraph_index, content, processed_content, char_count, created_at)
        VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
      `);
      const insertSent = sqlite.prepare(`
        INSERT INTO sentences (paper_id, paragraph_id, sentence_index, content, created_at)
        VALUES (?, ?, ?, ?, datetime('now'))
      `);

      const insertStructured = sqlite.transaction(() => {
        for (const section of structured) {
          for (const para of section.paragraphs) {
            const result = insertPara.run(
              paperId, para.sectionTitle, globalParaIndex, para.content, detectFormulas(para.content), para.charCount
            );
            const paraId = result.lastInsertRowid;

            for (let si = 0; si < para.sentences.length; si++) {
              insertSent.run(paperId, paraId, si, para.sentences[si]);
            }
            globalParaIndex++;
          }
        }
      });

      insertStructured();
      console.log(`[PDF处理] 段落拆分完成: ${globalParaIndex} 个段落`);

      db.update(papers).set({ paragraphStatus: 'ready' }).where(eq(papers.id, paperId)).run();
    } catch (e) {
      console.error('[PDF处理] 段落拆分失败:', e);
      db.update(papers).set({ paragraphStatus: 'error' }).where(eq(papers.id, paperId)).run();
    }

    // 更新处理状态
    db.update(papers).set({
      processingStatus: 'ready',
      abstract: fullText.slice(0, 500),
      updatedAt: new Date().toISOString(),
    }).where(eq(papers.id, paperId)).run();

    console.log(`[PDF处理] 论文处理完成: ${paperId}`);

    // 7. 异步渲染页面图片（不阻塞主流程）
    renderPageImages(pdfBuffer, paperId).catch((e) => {
      console.error(`[PDF处理] 页面图片渲染失败: ${paperId}`, e);
    });
  } catch (error) {
    console.error(`[PDF处理] 处理失败: ${paperId}`, error);
    db.update(papers).set({
      processingStatus: 'error',
      updatedAt: new Date().toISOString(),
    }).where(eq(papers.id, paperId)).run();
  }
}
