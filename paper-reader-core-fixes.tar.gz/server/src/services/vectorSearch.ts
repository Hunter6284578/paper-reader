import { eq } from 'drizzle-orm';
import { db, sqlite } from '../db/connection.js';
import { chunks } from '../db/schema.js';
import { getSingleEmbedding } from './embedding.js';
import { ENV } from '../config.js';

interface SearchResult {
  chunkId: number;
  content: string;
  sectionTitle: string | null;
  pageNumber: number | null;
  score: number;
}

/**
 * 混合检索：向量检索 + FTS5 关键词检索 → RRF 融合
 */
export async function hybridSearch(
  query: string,
  paperId: string,
  topN: number = 6
): Promise<SearchResult[]> {
  // 获取论文的所有 chunks
  const paperChunks = db.select().from(chunks).where(eq(chunks.paperId, paperId)).all();

  if (paperChunks.length === 0) {
    return [];
  }

  const hasEmbeddings = paperChunks.some((c) => c.embedding !== null);

  const merged = new Map<number, { result: SearchResult; rrfScore: number }>();

  // 1. 向量检索（如果有 embedding）
  if (hasEmbeddings && ENV.SILICONFLOW_API_KEY) {
    try {
      const queryEmbedding = await getSingleEmbedding(query);

      const vectorResults: SearchResult[] = paperChunks
        .filter((c) => c.embedding !== null)
        .map((c) => ({
          chunkId: c.id,
          content: c.content,
          sectionTitle: c.sectionTitle,
          pageNumber: c.pageNumber,
          score: cosineSimilarity(queryEmbedding, JSON.parse(c.embedding!) as number[]),
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, 8);

      // RRF 融合
      vectorResults.forEach((r, i) => {
        const rrfScore = 1 / (60 + i + 1);
        merged.set(r.chunkId, { result: r, rrfScore });
      });
    } catch (e) {
      console.warn('[向量检索] 失败，仅使用关键词检索:', e);
    }
  }

  // 2. FTS5 关键词检索
  try {
    const ftsResults = sqlite.prepare(`
      SELECT rowid, rank FROM chunks_fts
      WHERE chunks_fts MATCH ?
      ORDER BY rank LIMIT 4
    `).all(query) as Array<{ rowid: number; rank: number }>;

    ftsResults.forEach((r, i) => {
      const chunk = paperChunks.find((c) => c.id === r.rowid);
      if (!chunk) return;

      const rrfScore = 1 / (60 + i + 1);
      const existing = merged.get(r.rowid);
      if (existing) {
        existing.rrfScore += rrfScore;
      } else {
        merged.set(r.rowid, {
          result: {
            chunkId: chunk.id,
            content: chunk.content,
            sectionTitle: chunk.sectionTitle,
            pageNumber: chunk.pageNumber,
            score: 0,
          },
          rrfScore,
        });
      }
    });
  } catch (e) {
    console.warn('[FTS检索] 失败:', e);
  }

  // 3. 按 RRF 分数排序，取 Top-N
  return [...merged.values()]
    .sort((a, b) => b.rrfScore - a.rrfScore)
    .slice(0, topN)
    .map((m) => m.result);
}

/**
 * 余弦相似度计算
 */
function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }

  const denominator = Math.sqrt(normA) * Math.sqrt(normB);
  return denominator === 0 ? 0 : dotProduct / denominator;
}
